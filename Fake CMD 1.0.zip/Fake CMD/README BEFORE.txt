Fake CMD
Version 1.0
Made in:23/06/2022
Creator:Hyper-Z

READ THIS BEFORE OPEN FILES

Code:
FCMD

RECOMMENDATION:
Before doing so, it would be nice to open the task manager first

This folder have a few files:
1.Fake CMD.bat
2.MSG1.vbs (hidden)
3.README BEFORE.txt

THIS IS ONLY PRANK VIRUS NOT REAL VIRUS

You can prank your friends using this

|MUST READ THIS:
|Conditional:
|1.Don't Change fill files and folder
|2.Don't Check hidden items in view
|
|After view message "it's only prank"
|Open Task manager and select "Microsoft ® Windows Based Script Host" and press End Task

Thanks for download